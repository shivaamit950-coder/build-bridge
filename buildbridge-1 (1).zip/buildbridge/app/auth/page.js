"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabaseClient";

export default function AuthPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showEmail, setShowEmail] = useState(false);
  const supabase = createClient();

  async function handleGoogleSignIn() {
    setGoogleLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback?next=/onboarding` },
    });
    if (error) {
      setError(error.message);
      setGoogleLoading(false);
    }
    // On success, Supabase redirects the browser to Google — no further code runs here.
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${window.location.origin}/onboarding` },
    });
    setLoading(false);
    if (error) setError(error.message);
    else setSent(true);
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="max-w-sm w-full">
        <div className="text-center mb-8">
          <span className="w-12 h-12 rounded-2xl bg-royal flex items-center justify-center text-white font-bold mx-auto mb-4">
            BB
          </span>
          <h1 className="text-2xl font-semibold text-navy">BuildBridge</h1>
          <p className="text-slate-500 text-sm mt-1">Find who you need to build with.</p>
        </div>

        {sent ? (
          <div className="card p-6 text-center space-y-2 fade-in">
            <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald mx-auto">✓</div>
            <p className="text-sm text-navy font-medium">Check your email</p>
            <p className="text-xs text-slate-500">We sent a sign-in link to {email}.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Primary: Google sign-in */}
            <button
              onClick={handleGoogleSignIn}
              disabled={googleLoading}
              className="w-full flex items-center justify-center gap-3 px-4 py-3.5 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 disabled:opacity-50 transition-colors text-navy font-medium text-sm shadow-soft"
            >
              <GoogleIcon />
              {googleLoading ? "Connecting…" : "Continue with Google"}
            </button>

            {error && <p className="text-red-500 text-xs text-center">{error}</p>}

            {/* Secondary: email, tucked behind a toggle so Google stays the clear default */}
            {!showEmail ? (
              <button
                onClick={() => setShowEmail(true)}
                className="w-full text-center text-xs text-slate-400 hover:text-slate-500 transition-colors py-1"
              >
                or continue with email
              </button>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3 fade-in">
                <div className="flex items-center gap-3 py-1">
                  <div className="h-px bg-slate-200 flex-1" />
                  <span className="text-[11px] text-slate-400">EMAIL</span>
                  <div className="h-px bg-slate-200 flex-1" />
                </div>
                <input
                  type="email"
                  required
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-4 py-3.5 rounded-2xl border border-slate-200 focus:border-royal outline-none text-sm shadow-softer"
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full px-4 py-3.5 rounded-2xl bg-royal hover:bg-royal-600 disabled:opacity-50 transition-colors text-white font-medium text-sm shadow-soft"
                >
                  {loading ? "Sending…" : "Send sign-in link"}
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </main>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18">
      <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84c-.21 1.13-.84 2.09-1.8 2.73v2.27h2.92c1.7-1.57 2.68-3.88 2.68-6.64z" />
      <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.27c-.81.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.71H.96v2.33C2.44 15.98 5.48 18 9 18z" />
      <path fill="#FBBC05" d="M3.97 10.7c-.18-.54-.28-1.11-.28-1.7s.1-1.16.28-1.7V4.97H.96A8.996 8.996 0 000 9c0 1.45.35 2.83.96 4.03l3.01-2.33z" />
      <path fill="#EA4335" d="M9 3.58c1.32 0 2.51.45 3.44 1.35l2.59-2.59C13.46.89 11.43 0 9 0 5.48 0 2.44 2.02.96 4.97l3.01 2.33C4.68 5.16 6.66 3.58 9 3.58z" />
    </svg>
  );
}
