import { notFound } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import ProjectCard from "@/components/ProjectCard";
import MessageOwnerButton from "@/components/MessageOwnerButton";

export default async function PublicProfilePage({ params }) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user && params.id === user.id) {
    const { redirect } = await import("next/navigation");
    redirect("/profile");
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", params.id).single();
  if (!profile) notFound();

  const { data: projects } = await supabase.from("projects").select("*").eq("owner_id", profile.id);

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-10 space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-royal-50 dark:bg-royal/10 flex items-center justify-center text-royal font-semibold text-xl">
            {profile.name?.[0]?.toUpperCase() || "?"}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-navy dark:text-white truncate">{profile.name}</h1>
              {profile.verified && <span className="text-emerald text-xs">✓ Verified</span>}
            </div>
            <p className="text-xs text-slate-400 truncate">{profile.headline || profile.location}</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Stat label="Reputation" value={profile.reputation_score ?? 0} />
          <Stat label="Projects" value={projects?.length || 0} />
          <Stat label="Experience" value={profile.experience_years ? `${profile.experience_years}y` : "—"} />
        </div>

        <MessageOwnerButton ownerId={profile.id} ownerName={profile.name} />

        {profile.bio && <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{profile.bio}</p>}

        {profile.skills_have?.length > 0 && <TagBlock label="Skills" items={profile.skills_have} />}
        {profile.skills_needed?.length > 0 && <TagBlock label="Looking for" items={profile.skills_needed} />}
        {profile.industries?.length > 0 && <TagBlock label="Industries" items={profile.industries} />}
        {profile.collaboration_type?.length > 0 && <TagBlock label="Open to" items={profile.collaboration_type} />}

        {profile.portfolio_url && (
          <a href={profile.portfolio_url} target="_blank" rel="noopener noreferrer" className="text-royal text-sm font-medium block">
            View portfolio →
          </a>
        )}

        {projects?.length > 0 && (
          <div>
            <p className="text-sm font-semibold text-navy dark:text-white mb-3">Projects</p>
            <div className="grid grid-cols-1 gap-3">
              {projects.map((p) => <ProjectCard key={p.id} project={p} />)}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

function Stat({ label, value }) {
  return (
    <div className="card p-3 text-center">
      <p className="text-lg font-semibold text-navy dark:text-white">{value}</p>
      <p className="text-[10px] text-slate-400">{label}</p>
    </div>
  );
}

function TagBlock({ label, items }) {
  return (
    <div>
      <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {items.map((i) => (
          <span key={i} className="text-[11px] px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            {i}
          </span>
        ))}
      </div>
    </div>
  );
}
