import { SkeletonAvatar, SkeletonLine } from "@/components/Skeletons";

export default function ProfileLoading() {
  return (
    <main className="max-w-lg mx-auto px-5 pt-6">
      <div className="flex items-center gap-4 mb-6">
        <SkeletonAvatar size="w-16 h-16" />
        <div className="flex-1 space-y-2">
          <SkeletonLine width="w-32" />
          <SkeletonLine width="w-44" height="h-2.5" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="skeleton h-16 rounded-2xl" />
        <div className="skeleton h-16 rounded-2xl" />
        <div className="skeleton h-16 rounded-2xl" />
      </div>

      <div className="space-y-3">
        <SkeletonLine width="w-full" height="h-3" />
        <SkeletonLine width="w-5/6" height="h-3" />
        <SkeletonLine width="w-2/3" height="h-3" />
      </div>

      <div className="flex gap-2 mt-6">
        <div className="skeleton w-20 h-7 rounded-full" />
        <div className="skeleton w-24 h-7 rounded-full" />
        <div className="skeleton w-16 h-7 rounded-full" />
      </div>
    </main>
  );
}
