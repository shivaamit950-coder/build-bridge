import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import ProfileEditor from "@/components/ProfileEditor";
import SignInPrompt from "@/components/SignInPrompt";

export default async function MyProfilePage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return (
      <main className="max-w-lg mx-auto">
        <TopBar />
        <SignInPrompt
          title="Sign in to view your profile"
          description="Create a profile so others can find and message you."
        />
      </main>
    );
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  const { data: projects } = await supabase.from("projects").select("*").eq("owner_id", user.id);

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-10">
        <ProfileEditor profile={profile} projects={projects || []} />
      </div>
    </main>
  );
}
