import { SkeletonLine, SkeletonRow } from "@/components/Skeletons";

export default function MessagesLoading() {
  return (
    <main className="max-w-lg mx-auto px-5 pt-6">
      <SkeletonLine width="w-32" height="h-6" />
      <div className="space-y-2 mt-5">
        {Array.from({ length: 6 }).map((_, i) => (
          <SkeletonRow key={i} />
        ))}
      </div>
    </main>
  );
}
