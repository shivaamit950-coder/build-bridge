import { notFound } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import ChatRoom from "@/components/ChatRoom";
import TopBar from "@/components/TopBar";
import SignInPrompt from "@/components/SignInPrompt";

export default async function ChatPage({ params }) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return (
      <main className="max-w-lg mx-auto">
        <TopBar />
        <SignInPrompt
          title="Sign in to send a message"
          description="You'll need an account to start this conversation."
        />
      </main>
    );
  }

  const otherId = params.id;
  const { data: other } = await supabase.from("profiles").select("*").eq("id", otherId).single();
  if (!other) notFound();

  // Find existing conversation in either direction
  let { data: conversation } = await supabase
    .from("conversations")
    .select("*")
    .or(
      `and(user_a.eq.${user.id},user_b.eq.${otherId}),and(user_a.eq.${otherId},user_b.eq.${user.id})`
    )
    .maybeSingle();

  if (!conversation) {
    const { data: created } = await supabase
      .from("conversations")
      .insert({ user_a: user.id, user_b: otherId })
      .select()
      .single();
    conversation = created;
  }

  const { data: initialMessages } = await supabase
    .from("messages")
    .select("*")
    .eq("conversation_id", conversation.id)
    .order("created_at", { ascending: true });

  return (
    <ChatRoom
      conversationId={conversation.id}
      currentUserId={user.id}
      otherProfile={other}
      initialMessages={initialMessages || []}
    />
  );
}
