import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import DiscoverFilters from "@/components/DiscoverFilters";

export default async function DiscoverPage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const profilesQuery = supabase
    .from("profiles")
    .select("*")
    .eq("onboarded", true)
    .order("last_active", { ascending: false });
  if (user) profilesQuery.neq("id", user.id);
  const { data: profiles } = await profilesQuery;

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6">
        <h1 className="text-xl font-semibold text-navy dark:text-white mb-4">Discover</h1>
      </div>
      <DiscoverFilters profiles={profiles || []} projects={projects || []} currentUserId={user?.id ?? null} />
    </main>
  );
}
