"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabaseClient";
import { INDUSTRIES, COLLAB_TYPES, AVAILABILITY } from "@/lib/constants";

const STEPS = ["building", "skills_have", "skills_needed", "industries", "countries", "availability", "collab"];

export default function OnboardingPage() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    building: "", skills_have: "", skills_needed: "",
    industries: [], countries: "", availability: "", collab: [],
  });
  const [saving, setSaving] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  function toggleArr(field, value) {
    setData((d) => ({
      ...d,
      [field]: d[field].includes(value) ? d[field].filter((v) => v !== value) : [...d[field], value],
    }));
  }

  async function finish() {
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.push("/auth"); return; }

    await supabase.from("profiles").upsert({
      id: user.id,
      name: user.email.split("@")[0],
      bio: data.building,
      skills_have: data.skills_have.split(",").map((s) => s.trim()).filter(Boolean),
      skills_needed: data.skills_needed.split(",").map((s) => s.trim()).filter(Boolean),
      industries: data.industries,
      countries_interested: data.countries.split(",").map((s) => s.trim()).filter(Boolean),
      availability: data.availability,
      collaboration_type: data.collab,
      onboarded: true,
      last_active: new Date().toISOString(),
    });

    setSaving(false);
    router.push("/");
  }

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <main className="min-h-screen flex flex-col px-6 py-8 max-w-lg mx-auto">
      <div className="w-full h-1.5 rounded-full bg-slate-100 mb-8">
        <div className="h-full rounded-full bg-royal transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>

      <div className="flex-1 fade-in" key={step}>
        {step === 0 && (
          <Question title="What do you want to build?">
            <textarea
              autoFocus rows={4} value={data.building}
              onChange={(e) => setData({ ...data, building: e.target.value })}
              placeholder="e.g. A SaaS tool for freelancers to manage invoices"
              className="input"
            />
          </Question>
        )}
        {step === 1 && (
          <Question title="What skills do you have?" hint="Separate with commas">
            <input
              autoFocus value={data.skills_have}
              onChange={(e) => setData({ ...data, skills_have: e.target.value })}
              placeholder="e.g. Product design, fundraising, Figma"
              className="input"
            />
          </Question>
        )}
        {step === 2 && (
          <Question title="What skills do you need?" hint="Separate with commas">
            <input
              autoFocus value={data.skills_needed}
              onChange={(e) => setData({ ...data, skills_needed: e.target.value })}
              placeholder="e.g. Backend development, manufacturing"
              className="input"
            />
          </Question>
        )}
        {step === 3 && (
          <Question title="Which industries interest you?">
            <div className="flex flex-wrap gap-2">
              {INDUSTRIES.map((i) => (
                <Chip key={i} active={data.industries.includes(i)} onClick={() => toggleArr("industries", i)}>{i}</Chip>
              ))}
            </div>
          </Question>
        )}
        {step === 4 && (
          <Question title="Which countries do you want to collaborate in?" hint="Separate with commas, or type 'Anywhere'">
            <input
              autoFocus value={data.countries}
              onChange={(e) => setData({ ...data, countries: e.target.value })}
              placeholder="e.g. India, USA, Anywhere"
              className="input"
            />
          </Question>
        )}
        {step === 5 && (
          <Question title="How much time can you commit?">
            <div className="flex flex-col gap-2">
              {AVAILABILITY.map((a) => (
                <button
                  key={a} onClick={() => setData({ ...data, availability: a })}
                  className={`text-left px-4 py-3.5 rounded-2xl border text-sm transition-colors ${
                    data.availability === a ? "border-royal bg-royal-50 text-royal font-medium" : "border-slate-200 text-navy"
                  }`}
                >{a}</button>
              ))}
            </div>
          </Question>
        )}
        {step === 6 && (
          <Question title="What are you looking for?">
            <div className="flex flex-wrap gap-2">
              {COLLAB_TYPES.map((c) => (
                <Chip key={c.value} active={data.collab.includes(c.value)} onClick={() => toggleArr("collab", c.value)}>{c.label}</Chip>
              ))}
            </div>
          </Question>
        )}
      </div>

      <div className="flex gap-3 pt-8">
        {step > 0 && (
          <button onClick={() => setStep(step - 1)} className="px-5 py-3.5 rounded-2xl border border-slate-200 text-navy text-sm font-medium">
            Back
          </button>
        )}
        {step < STEPS.length - 1 ? (
          <button onClick={() => setStep(step + 1)} className="flex-1 px-5 py-3.5 rounded-2xl bg-royal text-white text-sm font-medium shadow-soft">
            Continue
          </button>
        ) : (
          <button onClick={finish} disabled={saving} className="flex-1 px-5 py-3.5 rounded-2xl bg-royal disabled:opacity-50 text-white text-sm font-medium shadow-soft">
            {saving ? "Saving…" : "Finish"}
          </button>
        )}
      </div>

      <style jsx global>{`
        .input {
          width: 100%; padding: 14px 16px; border-radius: 16px;
          border: 1px solid #e2e8f0; outline: none; font-size: 14px;
        }
        .input:focus { border-color: #2563EB; }
      `}</style>
    </main>
  );
}

function Question({ title, hint, children }) {
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-semibold text-navy">{title}</h1>
      {hint && <p className="text-xs text-slate-400">{hint}</p>}
      <div className="pt-1">{children}</div>
    </div>
  );
}

function Chip({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full border text-sm transition-colors ${
        active ? "border-royal bg-royal-50 text-royal font-medium" : "border-slate-200 text-navy"
      }`}
    >
      {children}
    </button>
  );
}
