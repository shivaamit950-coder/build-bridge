import { notFound } from "next/navigation";
import Link from "next/link";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import BookmarkButton from "@/components/BookmarkButton";
import MessageOwnerButton from "@/components/MessageOwnerButton";

export default async function ProjectDetailPage({ params }) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: project } = await supabase.from("projects").select("*").eq("id", params.id).single();
  if (!project) notFound();

  const { data: owner } = await supabase.from("profiles").select("*").eq("id", project.owner_id).single();

  let bookmark = null;
  if (user) {
    const { data } = await supabase
      .from("bookmarks")
      .select("*")
      .eq("user_id", user.id)
      .eq("project_id", project.id)
      .maybeSingle();
    bookmark = data;
  }

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-10 space-y-5">
        <div className="flex items-start justify-between gap-3">
          <h1 className="text-xl font-semibold text-navy dark:text-white leading-snug">{project.title}</h1>
          <BookmarkButton projectId={project.id} initiallyBookmarked={!!bookmark} />
        </div>

        <div className="flex flex-wrap gap-2">
          {project.stage && <Tag color="emerald">{project.stage}</Tag>}
          {project.industry && <Tag color="royal">{project.industry}</Tag>}
        </div>

        <Section label="Description">{project.description}</Section>
        {project.problem && <Section label="Problem being solved">{project.problem}</Section>}

        <div className="grid grid-cols-2 gap-4">
          <MiniStat label="Location" value={project.location || "Remote"} />
          <MiniStat label="Investment needed" value={project.investment_needed || "Not specified"} />
          <MiniStat label="Timeline" value={project.timeline || "Not specified"} />
          <MiniStat label="Commitment" value={project.commitment || "Flexible"} />
          {project.equity_offered && <MiniStat label="Equity offered" value={project.equity_offered} />}
        </div>

        {project.required_skills?.length > 0 && (
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">Skills needed</p>
            <div className="flex flex-wrap gap-2">
              {project.required_skills.map((s) => (
                <Tag key={s} color="slate">{s}</Tag>
              ))}
            </div>
          </div>
        )}

        {owner && (
          <Link href={`/profile/${owner.id}`} className="card p-4 flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-royal-50 dark:bg-royal/10 flex items-center justify-center text-royal font-semibold">
              {owner.name?.[0]?.toUpperCase() || "?"}
            </div>
            <div>
              <p className="text-xs text-slate-400">Posted by</p>
              <p className="text-sm font-medium text-navy dark:text-white">{owner.name}</p>
            </div>
          </Link>
        )}

        {owner && owner.id !== user?.id && <MessageOwnerButton ownerId={owner.id} ownerName={owner.name} />}
      </div>
    </main>
  );
}

function Section({ label, children }) {
  return (
    <div>
      <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">{label}</p>
      <p className="text-sm text-navy dark:text-slate-200 leading-relaxed">{children}</p>
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="card p-3">
      <p className="text-[10px] text-slate-400 mb-1">{label}</p>
      <p className="text-xs font-medium text-navy dark:text-white">{value}</p>
    </div>
  );
}

function Tag({ children, color }) {
  const colorMap = {
    emerald: "bg-emerald-50 text-emerald dark:bg-emerald/10",
    royal: "bg-royal-50 text-royal dark:bg-royal/10",
    slate: "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-300",
  };
  return <span className={`text-[11px] font-medium px-2.5 py-1 rounded-full ${colorMap[color]}`}>{children}</span>;
}
