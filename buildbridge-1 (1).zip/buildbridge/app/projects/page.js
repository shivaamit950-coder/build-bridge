import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import ProjectCard from "@/components/ProjectCard";
import NewProjectButton from "@/components/NewProjectButton";

export default async function ProjectsPage() {
  const supabase = createServerSupabase();

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 flex items-center justify-between mb-5">
        <h1 className="text-xl font-semibold text-navy dark:text-white">Projects</h1>
        <NewProjectButton />
      </div>

      <div className="px-5 grid grid-cols-1 gap-3 pb-6">
        {(!projects || projects.length === 0) && (
          <div className="card p-8 text-center">
            <p className="text-sm text-slate-400">No projects posted yet.</p>
          </div>
        )}
        {projects?.map((p) => (
          <ProjectCard key={p.id} project={p} />
        ))}
      </div>
    </main>
  );
}
