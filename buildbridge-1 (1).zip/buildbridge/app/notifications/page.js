import { redirect } from "next/navigation";
import Link from "next/link";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";

export default async function NotificationsPage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/auth");

  const { data: notifications } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-10">
        <h1 className="text-xl font-semibold text-navy dark:text-white mb-5">Notifications</h1>

        <div className="space-y-2">
          {(!notifications || notifications.length === 0) && (
            <div className="card p-8 text-center">
              <p className="text-sm text-slate-400">Nothing yet — you'll see matches, messages, and updates here.</p>
            </div>
          )}
          {notifications?.map((n) => (
            <Link
              key={n.id}
              href={n.link || "#"}
              className={`card p-4 flex items-start gap-3 ${!n.read ? "border-l-2 border-royal" : ""}`}
            >
              <span className="text-lg shrink-0">
                {n.type === "message" ? "💬" : n.type === "match" ? "✦" : n.type === "connection_request" ? "🤝" : "🔔"}
              </span>
              <div>
                <p className="text-sm text-navy dark:text-white">{n.body}</p>
                <p className="text-[10px] text-slate-400 mt-1">{new Date(n.created_at).toLocaleDateString()}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </main>
  );
}
