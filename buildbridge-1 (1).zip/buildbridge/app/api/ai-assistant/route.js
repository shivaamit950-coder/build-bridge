import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabaseServer";
import { callAI } from "@/lib/aiProviders";
import { checkRateLimit } from "@/lib/rateLimit";

const SYSTEM_PROMPT = `You are the BuildBridge AI Assistant — a sharp, practical startup advisor built into a partner-matching app.

You help people:
- Improve and stress-test their startup idea
- Review business plans for gaps
- Suggest what kind of team members/roles they need (and why)
- Give realistic cost estimates when asked
- Recommend concrete next steps

Be direct and specific, not generic. Reference the person's actual project details when they're provided. Keep responses focused — a few short paragraphs or a tight list, not an essay. Never fabricate specific market-size numbers or funding data you don't have; give ranges and say when something needs real research.`;

const MAX_MESSAGE_LENGTH = 4000;
const MAX_MESSAGES_PER_REQUEST = 30;

export async function POST(request) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const rateCheck = await checkRateLimit(user.id, "ai_assistant", 30);
  if (!rateCheck.allowed) {
    return NextResponse.json(
      { error: `You've hit the hourly limit for AI Assistant. Try again in ${rateCheck.retryAfterMinutes} minutes.` },
      { status: 429 }
    );
  }

  const { messages, projectContext, provider } = await request.json();

  if (!Array.isArray(messages) || messages.length === 0) {
    return NextResponse.json({ error: "No messages provided." }, { status: 400 });
  }
  if (messages.length > MAX_MESSAGES_PER_REQUEST) {
    return NextResponse.json({ error: "Conversation too long — start a new one." }, { status: 400 });
  }
  if (messages.some((m) => typeof m.content !== "string" || m.content.length > MAX_MESSAGE_LENGTH)) {
    return NextResponse.json({ error: "Message too long." }, { status: 400 });
  }

  const contextBlock = projectContext
    ? `\n\nThe person's current project context:\n${JSON.stringify(projectContext, null, 2)}`
    : "";

  try {
    const { text } = await callAI({
      provider,
      system: SYSTEM_PROMPT + contextBlock,
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
    });
    return NextResponse.json({ reply: text });
  } catch (err) {
    return NextResponse.json({ error: "AI Assistant failed: " + err.message }, { status: 500 });
  }
}

