import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabaseServer";
import { callAI } from "@/lib/aiProviders";
import { checkRateLimit } from "@/lib/rateLimit";

export async function POST(request) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const rateCheck = await checkRateLimit(user.id, "ai_match", 10);
  if (!rateCheck.allowed) {
    return NextResponse.json(
      { error: `You've hit the hourly limit for AI Match. Try again in ${rateCheck.retryAfterMinutes} minutes.` },
      { status: 429 }
    );
  }

  const { provider } = await request.json().catch(() => ({}));

  const { data: me } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  if (!me) {
    return NextResponse.json({ error: "Profile not found — finish onboarding first" }, { status: 400 });
  }

  // Candidate pool: everyone except me, capped to keep the prompt small and cheap
  const { data: candidates } = await supabase
    .from("profiles")
    .select("*")
    .neq("id", user.id)
    .eq("onboarded", true)
    .limit(25);

  if (!candidates || candidates.length === 0) {
    return NextResponse.json({ matches: [] });
  }

  const prompt = `You are a compatibility engine for a startup-partner-matching app called BuildBridge.

Score how well each CANDIDATE complements ME as a business-building partner (co-founder, manufacturer, marketer, developer, investor, designer, advisor, etc.) — not how similar we are, but how well our skills, goals, and needs fit together.

ME:
${JSON.stringify(
  {
    building: me.bio,
    skills_have: me.skills_have,
    skills_needed: me.skills_needed,
    industries: me.industries,
    availability: me.availability,
    collaboration_type: me.collaboration_type,
    countries_interested: me.countries_interested,
  },
  null,
  2
)}

CANDIDATES:
${JSON.stringify(
  candidates.map((c) => ({
    id: c.id,
    name: c.name,
    building: c.bio,
    skills_have: c.skills_have,
    skills_needed: c.skills_needed,
    industries: c.industries,
    availability: c.availability,
    collaboration_type: c.collaboration_type,
    countries_interested: c.countries_interested,
  })),
  null,
  2
)}

Return ONLY a JSON array, no other text, no markdown fences. One object per candidate:
[{ "id": "candidate-id", "score": 0-100, "reasoning": "one short sentence, specific to these two profiles" }]

Score based on: do their skills_have cover my skills_needed (and vice versa)? Do industries/interests overlap? Is availability and collaboration_type compatible? Is there real complementary fit, not just similarity.`;

  let matches = [];
  try {
    const { text } = await callAI({
      provider,
      messages: [{ role: "user", content: prompt }],
      maxTokens: 2000,
    });
    const cleaned = text.replace(/```json|```/g, "").trim();
    matches = JSON.parse(cleaned);
  } catch (err) {
    return NextResponse.json({ error: "AI matching failed: " + err.message }, { status: 500 });
  }

  // Cache scores so we don't recompute on every page load
  const rows = matches.map((m) => ({
    user_id: user.id,
    matched_profile_id: m.id,
    score: m.score,
    reasoning: m.reasoning,
  }));
  if (rows.length > 0) {
    await supabase.from("match_scores").upsert(rows, { onConflict: "user_id,matched_profile_id" });
  }

  const candidateMap = Object.fromEntries(candidates.map((c) => [c.id, c]));
  const enriched = matches
    .filter((m) => candidateMap[m.id])
    .sort((a, b) => b.score - a.score)
    .map((m) => ({ ...m, profile: candidateMap[m.id] }));

  return NextResponse.json({ matches: enriched });
}
