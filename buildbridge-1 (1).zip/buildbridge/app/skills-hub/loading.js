import { SkeletonLine, SkeletonHRow } from "@/components/Skeletons";

export default function SkillsHubLoading() {
  return (
    <main className="max-w-lg mx-auto px-5 pt-6">
      <SkeletonLine width="w-32" height="h-6" />
      <SkeletonLine width="w-48" height="h-3" />
      <div className="flex gap-2 my-4">
        <div className="skeleton w-28 h-9 rounded-xl" />
        <div className="skeleton w-32 h-9 rounded-xl" />
      </div>
      <div className="skeleton w-full h-12 rounded-2xl mb-3" />
      <div className="flex gap-2 mb-5">
        <div className="skeleton w-24 h-9 rounded-xl" />
        <div className="skeleton w-20 h-9 rounded-xl" />
        <div className="skeleton w-24 h-9 rounded-xl" />
      </div>
      <div className="-mx-5 space-y-6">
        <div>
          <div className="px-5 mb-3"><SkeletonLine width="w-36" /></div>
          <SkeletonHRow count={3} />
        </div>
        <div>
          <div className="px-5 mb-3"><SkeletonLine width="w-40" /></div>
          <SkeletonHRow count={3} />
        </div>
      </div>
    </main>
  );
}
