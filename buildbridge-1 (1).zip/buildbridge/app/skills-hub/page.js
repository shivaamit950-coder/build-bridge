import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import SkillsHub from "@/components/SkillsHub";

export default async function SkillsHubPage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  let myProfile = null;
  if (user) {
    const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single();
    myProfile = data;
  }

  const expertsQuery = supabase
    .from("profiles")
    .select("*")
    .eq("is_offering_skills", true)
    .order("last_active", { ascending: false });
  if (user) expertsQuery.neq("id", user.id);
  const { data: experts } = await expertsQuery;

  // "Learners" = people looking to learn a skill (collaboration_type includes learn_skill), not currently offering
  const learnersQuery = supabase
    .from("profiles")
    .select("*")
    .contains("collaboration_type", ["learn_skill"])
    .order("last_active", { ascending: false });
  if (user) learnersQuery.neq("id", user.id);
  const { data: learners } = await learnersQuery;

  return (
    <main className="max-w-lg mx-auto">
      <TopBar showMessages />
      <SkillsHub myProfile={myProfile} experts={experts || []} learners={learners || []} currentUserId={user?.id ?? null} />
    </main>
  );
}
