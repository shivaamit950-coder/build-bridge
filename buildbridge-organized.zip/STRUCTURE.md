# BuildBridge Project Structure

## Directory Organization

```
buildbridge/
├── app/                          # Next.js 14 App Router
│   ├── layout.js                # Root layout (providers, metadata, PWA)
│   │
│   ├── (marketing)/              # Public landing pages
│   │   ├── page.js              # Home
│   │   └── layout.js
│   │
│   ├── (app)/                    # Authenticated app pages with BottomNav
│   │   ├── layout.js            # Includes BottomNav
│   │   ├── error.js
│   │   ├── loading.js
│   │   ├── discover/
│   │   │   └── page.js          # Find talent & projects
│   │   ├── messages/
│   │   │   └── page.js          # Messaging
│   │   ├── chat/
│   │   │   └── page.js          # AI Chat
│   │   └── profile/
│   │       └── page.js          # User profile
│   │
│   ├── (auth)/                   # Auth pages (no BottomNav)
│   │   ├── layout.js
│   │   ├── login/
│   │   │   └── page.js
│   │   └── onboarding/
│   │       └── page.js
│   │
│   └── api/                      # Backend API routes (organized by domain)
│       ├── auth/
│       │   └── me/
│       │       └── route.js      # GET /api/auth/me
│       ├── ai/
│       │   └── chat/
│       │       └── route.js      # POST /api/ai/chat
│       ├── messages/
│       │   └── send/
│       │       └── route.js      # POST /api/messages/send
│       ├── profiles/
│       │   └── search/
│       │       └── route.js      # GET /api/profiles/search
│       └── webhooks/             # Reserved for Supabase webhooks
│
├── src/                          # Source code (reusable logic & UI)
│   ├── components/               # 20 reusable React components
│   │   ├── AuthProvider.jsx
│   │   ├── BottomNav.jsx        # Bottom navigation
│   │   ├── TopBar.jsx           # Top bar with profile/sign in
│   │   ├── ChatRoom.jsx         # AI chat interface
│   │   ├── DiscoverFilters.jsx  # Search & filter UI
│   │   ├── OfferSkillsForm.jsx  # Create skill offering
│   │   ├── ProfileEditor.jsx    # Edit profile
│   │   ├── ProjectCard.jsx      # Project display card
│   │   ├── SkillProfileCard.jsx # Talent display card
│   │   ├── SkillsHub.jsx        # Skills marketplace
│   │   ├── CommunityShowcase.jsx
│   │   ├── HomeSearch.jsx
│   │   ├── JourneyCards.jsx
│   │   ├── SignInPrompt.jsx
│   │   ├── ThemeProvider.jsx
│   │   ├── Skeletons.jsx
│   │   ├── BookmarkButton.jsx
│   │   ├── MessageOwnerButton.jsx
│   │   ├── NewProjectButton.jsx
│   │   ├── ServiceWorkerRegister.jsx
│   │   └── CommunityShowcase.jsx
│   │
│   ├── lib/                      # Utilities & configuration
│   │   ├── supabaseClient.js    # Client-side Supabase
│   │   ├── supabaseServer.js    # Server-side Supabase (SSR)
│   │   ├── aiProviders.js       # Claude, OpenAI, Google configs
│   │   ├── constants.js         # App constants (industries, stages, etc)
│   │   └── rateLimit.js         # Rate limiting utilities
│   │
│   ├── hooks/                    # Custom React hooks
│   │   └── useLocation.js       # Geolocation & distance filtering
│   │
│   └── styles/                   # CSS & styling
│       └── globals.css          # Global styles (Tailwind, reset)
│
├── public/                       # Static assets
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── icon-maskable-512.png
│   ├── manifest.json            # PWA manifest
│   └── sw.js                    # Service worker
│
├── Root Config Files
│   ├── package.json              # Dependencies & scripts
│   ├── next.config.js           # Next.js configuration
│   ├── tsconfig.json            # TypeScript config (path aliases: @/*)
│   ├── jsconfig.json            # JavaScript config (path aliases: @/*)
│   ├── tailwind.config.js       # Tailwind CSS config
│   ├── postcss.config.js        # PostCSS config
│   ├── middleware.js            # Next.js middleware (auth checks)
│   ├── vercel.json              # Vercel deployment config
│   ├── .env.example             # Environment variables template
│   ├── .gitignore               # Git ignore rules
│   └── README.md                # Project documentation
```

## Path Aliases

All imports use `@/` prefix mapped to `src/`:

```javascript
// Components
import TopBar from "@/components/TopBar";
import BottomNav from "@/components/BottomNav";

// Utilities
import { createServerSupabase } from "@/lib/supabaseServer";
import { INDUSTRIES } from "@/lib/constants";

// Hooks
import { useLocation } from "@/hooks/useLocation";

// Styles
import "@/styles/globals.css";
```

## Page Routes

| Route | Group | Component | Feature |
|-------|-------|-----------|---------|
| `/` | (marketing) | home page | Landing/home |
| `/discover` | (app) | discover/page.js | Hire Talent + Build Together |
| `/messages` | (app) | messages/page.js | Messaging |
| `/chat` | (app) | chat/page.js | AI Chat |
| `/profile` | (app) | profile/page.js | User Profile |
| `/login` | (auth) | login/page.js | Sign In |
| `/onboarding` | (auth) | onboarding/page.js | Profile Setup |

## API Routes

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/auth/me` | GET | Get current user |
| `/api/ai/chat` | POST | Chat with Claude |
| `/api/messages/send` | POST | Send message |
| `/api/profiles/search` | GET | Search profiles |
| `/api/webhooks/*` | — | Supabase webhook handlers |

## Build & Deployment

### Build Status
- ✅ TypeScript compilation successful
- ✅ Next.js 14 App Router working
- ✅ Path aliases configured correctly
- ⚠️  Static generation requires `.env` with Supabase keys

### Environment Variables (`.env` required for build)
```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
GOOGLE_GENERATIVE_AI_KEY=
```

### Scripts
- `npm run dev` — Start development server
- `npm run build` — Build for production
- `npm run start` — Start production server
- `npm run lint` — Run ESLint
- `npm run type-check` — Check TypeScript

## Key Features

### Authentication
- Google OAuth via Supabase
- Magic link sign-in
- Session management with Supabase RLS

### Pages
- **Discover** — Search and filter profiles/projects by location (5/10/25/50 km), skills, stage, industry
- **Messages** — Real-time messaging with file sharing
- **AI Chat** — Claude-powered assistant
- **Profile** — Create/edit profiles (Hire Talent or Build Together)

### Components
- **Responsive UI** — Mobile-first design (max-w-lg)
- **Dark Mode** — ThemeProvider with system preference
- **Navigation** — Bottom nav (Home/Messages/AI Chat/Profile) on app routes
- **PWA** — Service worker, manifest, offline support

## Development Workflow

1. **Install**: `npm install`
2. **Setup .env** with Supabase credentials
3. **Dev server**: `npm run dev` (http://localhost:3000)
4. **Make changes** in src/ and app/
5. **Build test**: `npm run build`
6. **Commit**: `git add . && git commit -m "..."`
7. **Push**: `git push origin main`

## Notes

- All routes except (marketing) require authentication
- (app) routes include BottomNav automatically via layout
- (auth) routes are simple layouts without navigation
- API routes have built-in auth middleware
- Tailwind CSS for styling
- Next.js 14.2.35 with React 18.3.1
- Supabase for backend (auth, database, real-time)
