import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import ProfileEditor from "@/components/ProfileEditor";

export const metadata = {
  title: "Onboarding - BuildBridge",
  description: "Complete your profile setup",
};

export default async function OnboardingPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (profile?.onboarded) redirect("/");

  return (
    <main className="max-w-lg mx-auto">
      <div className="px-5 pt-12 pb-4">
        <h1 className="text-3xl font-bold text-navy dark:text-white mb-2">
          Complete Your Profile
        </h1>
        <p className="text-slate-600 dark:text-slate-400 mb-8">
          Help others find you. Tell us about yourself.
        </p>
      </div>
      <ProfileEditor profile={profile} isOnboarding />
    </main>
  );
}
