import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import SignInPrompt from "@/components/SignInPrompt";

export const metadata = {
  title: "Sign In - BuildBridge",
  description: "Sign in to BuildBridge",
};

export default async function LoginPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (user) redirect("/");

  return (
    <main className="max-w-lg mx-auto min-h-screen flex items-center justify-center px-5">
      <div className="w-full">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-navy dark:text-white mb-2">
            BuildBridge
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Find your perfect co-founder
          </p>
        </div>
        <SignInPrompt />
      </div>
    </main>
  );
}
