import { createServerSupabase } from "@/lib/supabaseServer";
import { NextResponse } from "next/server";

export async function POST(req) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { conversation_id, message_text } = await req.json();

  if (!conversation_id || !message_text) {
    return NextResponse.json(
      { error: "conversation_id and message_text required" },
      { status: 400 }
    );
  }

  const { data, error } = await supabase
    .from("messages")
    .insert({
      conversation_id,
      sender_id: user.id,
      message_text,
      created_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ message: data });
}
