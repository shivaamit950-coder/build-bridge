import { createServerSupabase } from "@/lib/supabaseServer";
import { NextResponse } from "next/server";

export async function GET(req) {
  const supabase = createServerSupabase();
  const { searchParams } = new URL(req.url);
  const query = searchParams.get("q");
  const lat = searchParams.get("lat");
  const lng = searchParams.get("lng");
  const radius = searchParams.get("radius") || 50;

  if (!query) {
    return NextResponse.json({ error: "Query required" }, { status: 400 });
  }

  let queryBuilder = supabase
    .from("profiles")
    .select("*")
    .eq("onboarded", true);

  // Add search filter
  queryBuilder = queryBuilder.or(`name.ilike.%${query}%,bio.ilike.%${query}%`);

  const { data } = await queryBuilder.limit(20);

  return NextResponse.json({ results: data });
}
