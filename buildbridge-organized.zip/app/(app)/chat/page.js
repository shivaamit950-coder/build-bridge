import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import ChatRoom from "@/components/ChatRoom";

export const metadata = {
  title: "AI Chat - BuildBridge",
  description: "Chat with AI assistant",
};

export default async function ChatPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-2xl font-semibold text-navy dark:text-white mb-4">
          AI Assistant
        </h1>
      </div>
      <ChatRoom />
    </main>
  );
}
