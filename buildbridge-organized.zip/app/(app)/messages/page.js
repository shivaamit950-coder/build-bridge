import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";

export const metadata = {
  title: "Messages - BuildBridge",
  description: "Chat with connections",
};

export default async function MessagesPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: conversations } = await supabase
    .from("conversations")
    .select("*")
    .eq("user_id", user.id)
    .order("updated_at", { ascending: false });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-2xl font-semibold text-navy dark:text-white mb-4">
          Messages
        </h1>
      </div>

      <div className="px-5 space-y-2 pb-20">
        {conversations?.length ? (
          conversations.map((conv) => (
            <div key={conv.id} className="p-4 border rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900">
              <p className="font-medium">{conv.participant_name}</p>
              <p className="text-sm text-slate-500 truncate">{conv.last_message}</p>
            </div>
          ))
        ) : (
          <p className="text-center text-slate-400 py-8">No conversations yet</p>
        )}
      </div>
    </main>
  );
}
