import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import DiscoverFilters from "@/components/DiscoverFilters";
import ProjectCard from "@/components/ProjectCard";
import SkillProfileCard from "@/components/SkillProfileCard";

export const metadata = {
  title: "Discover - BuildBridge",
  description: "Find co-founders, talent, and projects",
};

export default async function DiscoverPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profiles } = await supabase
    .from("profiles")
    .select("*")
    .eq("onboarded", true)
    .limit(20);

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .limit(20);

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-2xl font-semibold text-navy dark:text-white mb-4">
          Discover
        </h1>
        <DiscoverFilters />
      </div>

      <div className="px-5 space-y-4 pb-20">
        {projects?.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
        {profiles?.map((profile) => (
          <SkillProfileCard key={profile.id} profile={profile} />
        ))}
      </div>
    </main>
  );
}
