import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import ProfileEditor from "@/components/ProfileEditor";

export const metadata = {
  title: "Profile - BuildBridge",
  description: "Manage your profile",
};

export default async function ProfilePage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-2xl font-semibold text-navy dark:text-white mb-4">
          Profile
        </h1>
      </div>
      <ProfileEditor profile={profile} />
      <div className="h-20" />
    </main>
  );
}
