"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabaseClient";

export default function AuthPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const supabase = createClient();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${window.location.origin}/onboarding` },
    });
    setLoading(false);
    if (error) setError(error.message);
    else setSent(true);
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="max-w-sm w-full">
        <div className="text-center mb-8">
          <span className="w-12 h-12 rounded-2xl bg-royal flex items-center justify-center text-white font-bold mx-auto mb-4">
            BB
          </span>
          <h1 className="text-2xl font-semibold text-navy">BuildBridge</h1>
          <p className="text-slate-500 text-sm mt-1">Find who you need to build with.</p>
        </div>

        {sent ? (
          <div className="card p-6 text-center space-y-2 fade-in">
            <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald mx-auto">✓</div>
            <p className="text-sm text-navy font-medium">Check your email</p>
            <p className="text-xs text-slate-500">We sent a sign-in link to {email}.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-4 py-3.5 rounded-2xl border border-slate-200 focus:border-royal outline-none text-sm shadow-softer"
            />
            {error && <p className="text-red-500 text-xs">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full px-4 py-3.5 rounded-2xl bg-royal hover:bg-royal-600 disabled:opacity-50 transition-colors text-white font-medium text-sm shadow-soft"
            >
              {loading ? "Sending…" : "Continue with email"}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
