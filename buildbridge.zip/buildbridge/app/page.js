import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import HomeSearch from "@/components/HomeSearch";
import JourneyCards from "@/components/JourneyCards";
import CommunityShowcase from "@/components/CommunityShowcase";

export default async function HomePage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/auth");

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  if (profile && !profile.onboarded) redirect("/onboarding");

  const { data: stats } = await supabase.from("community_stats").select("*").eq("id", 1).single();

  const { data: builders } = await supabase
    .from("profiles")
    .select("*")
    .eq("onboarded", true)
    .neq("id", user.id)
    .order("reputation_score", { ascending: false })
    .limit(6);

  const { data: experts } = await supabase
    .from("profiles")
    .select("*")
    .eq("is_offering_skills", true)
    .neq("id", user.id)
    .order("rating", { ascending: false })
    .limit(6);

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(6);

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />

      <div className="px-5 pt-6 pb-4">
        <h1 className="text-2xl font-semibold text-navy dark:text-white mb-1">
          Hey{profile?.name ? `, ${profile.name}` : ""} 👋
        </h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mb-5">
          Find the right partner to build with.
        </p>
        <HomeSearch />
      </div>

      <JourneyCards />
      <CommunityShowcase stats={stats} builders={builders} experts={experts} projects={projects} />

      <div className="h-6" />
    </main>
  );
}
