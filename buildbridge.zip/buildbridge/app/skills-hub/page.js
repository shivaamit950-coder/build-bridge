import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import SkillsHub from "@/components/SkillsHub";

export default async function SkillsHubPage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/auth");

  const { data: myProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single();

  const { data: experts } = await supabase
    .from("profiles")
    .select("*")
    .eq("is_offering_skills", true)
    .neq("id", user.id)
    .order("last_active", { ascending: false });

  // "Learners" = people looking to learn a skill (collaboration_type includes learn_skill), not currently offering
  const { data: learners } = await supabase
    .from("profiles")
    .select("*")
    .contains("collaboration_type", ["learn_skill"])
    .neq("id", user.id)
    .order("last_active", { ascending: false });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar showMessages />
      <SkillsHub myProfile={myProfile} experts={experts || []} learners={learners || []} currentUserId={user.id} />
    </main>
  );
}
