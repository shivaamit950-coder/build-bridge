"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabaseClient";
import { INDUSTRIES, STAGES } from "@/lib/constants";
import TopBar from "@/components/TopBar";

export default function NewProjectPage() {
  const [form, setForm] = useState({
    title: "", description: "", problem: "", stage: "Idea", industry: INDUSTRIES[0],
    required_skills: "", location: "", investment_needed: "", timeline: "", equity_offered: "", commitment: "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();
  const supabase = createClient();

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError("");

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.push("/auth"); return; }

    const { data, error } = await supabase
      .from("projects")
      .insert({
        owner_id: user.id,
        title: form.title,
        description: form.description,
        problem: form.problem,
        stage: form.stage,
        industry: form.industry,
        required_skills: form.required_skills.split(",").map((s) => s.trim()).filter(Boolean),
        location: form.location,
        investment_needed: form.investment_needed,
        timeline: form.timeline,
        equity_offered: form.equity_offered,
        commitment: form.commitment,
      })
      .select()
      .single();

    setSaving(false);
    if (error) { setError(error.message); return; }
    router.push(`/projects/${data.id}`);
  }

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-10">
        <h1 className="text-xl font-semibold text-navy dark:text-white mb-5">Post a project</h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Title">
            <input required value={form.title} onChange={(e) => update("title", e.target.value)}
              placeholder="e.g. AI-powered invoice tool for freelancers" className="input" />
          </Field>

          <Field label="Description">
            <textarea required rows={3} value={form.description} onChange={(e) => update("description", e.target.value)}
              placeholder="What is it, and what does it do?" className="input" />
          </Field>

          <Field label="Problem you're solving">
            <textarea rows={2} value={form.problem} onChange={(e) => update("problem", e.target.value)}
              placeholder="What pain point does this address?" className="input" />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Stage">
              <select value={form.stage} onChange={(e) => update("stage", e.target.value)} className="input">
                {STAGES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Industry">
              <select value={form.industry} onChange={(e) => update("industry", e.target.value)} className="input">
                {INDUSTRIES.map((i) => <option key={i}>{i}</option>)}
              </select>
            </Field>
          </div>

          <Field label="Required skills" hint="Separate with commas">
            <input value={form.required_skills} onChange={(e) => update("required_skills", e.target.value)}
              placeholder="e.g. Backend development, manufacturing, sales" className="input" />
          </Field>

          <Field label="Location">
            <input value={form.location} onChange={(e) => update("location", e.target.value)}
              placeholder="e.g. Remote, or Amritsar, India" className="input" />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Investment needed">
              <input value={form.investment_needed} onChange={(e) => update("investment_needed", e.target.value)}
                placeholder="e.g. ₹5L, or Bootstrapped" className="input" />
            </Field>
            <Field label="Timeline">
              <input value={form.timeline} onChange={(e) => update("timeline", e.target.value)}
                placeholder="e.g. 3 months to MVP" className="input" />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Equity offered" hint="Optional">
              <input value={form.equity_offered} onChange={(e) => update("equity_offered", e.target.value)}
                placeholder="e.g. 5-10%" className="input" />
            </Field>
            <Field label="Expected commitment">
              <input value={form.commitment} onChange={(e) => update("commitment", e.target.value)}
                placeholder="e.g. 10 hrs/week" className="input" />
            </Field>
          </div>

          {error && <p className="text-red-500 text-xs">{error}</p>}

          <button type="submit" disabled={saving}
            className="w-full px-5 py-3.5 rounded-2xl bg-royal disabled:opacity-50 text-white text-sm font-medium shadow-soft">
            {saving ? "Posting…" : "Post project"}
          </button>
        </form>
      </div>

      <style jsx global>{`
        .input {
          width: 100%; padding: 13px 16px; border-radius: 14px;
          border: 1px solid #e2e8f0; outline: none; font-size: 14px; background: white;
        }
        .input:focus { border-color: #2563EB; }
        body.dark .input { background: #111827; border-color: #1e293b; color: white; }
      `}</style>
    </main>
  );
}

function Field({ label, hint, children }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-slate-500 dark:text-slate-400">
        {label} {hint && <span className="text-slate-300">— {hint}</span>}
      </label>
      {children}
    </div>
  );
}
