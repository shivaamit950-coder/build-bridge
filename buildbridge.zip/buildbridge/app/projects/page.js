import { redirect } from "next/navigation";
import Link from "next/link";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";
import ProjectCard from "@/components/ProjectCard";

export default async function ProjectsPage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/auth");

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 flex items-center justify-between mb-5">
        <h1 className="text-xl font-semibold text-navy dark:text-white">Projects</h1>
        <Link
          href="/projects/new"
          className="px-4 py-2 rounded-xl bg-royal text-white text-xs font-medium shadow-soft"
        >
          + New project
        </Link>
      </div>

      <div className="px-5 grid grid-cols-1 gap-3 pb-6">
        {(!projects || projects.length === 0) && (
          <div className="card p-8 text-center">
            <p className="text-sm text-slate-400">No projects posted yet.</p>
            <Link href="/projects/new" className="text-royal text-sm font-medium mt-2 inline-block">
              Post the first one →
            </Link>
          </div>
        )}
        {projects?.map((p) => (
          <ProjectCard key={p.id} project={p} />
        ))}
      </div>
    </main>
  );
}
