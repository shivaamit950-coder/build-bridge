import { redirect } from "next/navigation";
import Link from "next/link";
import { createServerSupabase } from "@/lib/supabaseServer";
import TopBar from "@/components/TopBar";

export default async function MessagesPage() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/auth");

  const { data: conversations } = await supabase
    .from("conversations")
    .select("*")
    .or(`user_a.eq.${user.id},user_b.eq.${user.id}`)
    .order("created_at", { ascending: false });

  const otherIds = (conversations || []).map((c) => (c.user_a === user.id ? c.user_b : c.user_a));
  let others = [];
  if (otherIds.length > 0) {
    const { data } = await supabase.from("profiles").select("*").in("id", otherIds);
    others = data || [];
  }

  const rows = (conversations || []).map((c) => {
    const otherId = c.user_a === user.id ? c.user_b : c.user_a;
    const other = others.find((o) => o.id === otherId);
    return { conversation: c, other };
  });

  return (
    <main className="max-w-lg mx-auto">
      <TopBar />
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-xl font-semibold text-navy dark:text-white">Messages</h1>
      </div>

      <div className="px-5 space-y-2 pb-6">
        {rows.length === 0 && (
          <div className="card p-8 text-center">
            <p className="text-sm text-slate-400">No conversations yet.</p>
            <Link href="/discover" className="text-royal text-sm font-medium mt-2 inline-block">
              Find someone to message →
            </Link>
          </div>
        )}
        {rows.map(({ conversation, other }) => (
          <Link
            key={conversation.id}
            href={`/messages/${other?.id}`}
            className="card p-4 flex items-center gap-3"
          >
            <div className="w-11 h-11 rounded-full bg-royal-50 dark:bg-royal/10 flex items-center justify-center text-royal font-semibold shrink-0">
              {other?.name?.[0]?.toUpperCase() || "?"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-navy dark:text-white truncate">{other?.name || "Unknown"}</p>
              <p className="text-xs text-slate-400 truncate">{other?.headline || "Tap to open conversation"}</p>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
